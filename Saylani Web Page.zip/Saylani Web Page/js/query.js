	$('.count').counterUp({delay:33,time:3000});

	    setTimeout(function(){
        $('.preloader').fadeToggle();
    }, 1500);
